import { collect } from "@/lib/collect"
import SummaryCards from "@/components/SummaryCards"
import ProjectTable from "@/components/ProjectTable"
import DailyChart from "@/components/DailyChart"
import RefreshButton from "@/components/RefreshButton"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

export const dynamic = "force-dynamic"

export default function Page() {
  const { byProject, byDay, totalFiles, totalEntries, skippedDup } = collect()

  const dayData = Object.entries(byDay)
    .filter(([date]) => date !== "unknown")
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, stats]) => ({ date, ...stats }))

  const generatedAt = new Date().toLocaleString("ja-JP", {
    timeZone: "Asia/Tokyo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  })

  return (
    <main className="mx-auto max-w-screen-xl px-4 py-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Claude Token Dashboard</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            ~/.claude/projects/ &nbsp;·&nbsp; {generatedAt} JST
          </p>
        </div>
        <RefreshButton />
      </div>

      {/* Summary cards */}
      <SummaryCards
        byProject={byProject}
        byDay={byDay}
        totalFiles={totalFiles}
        totalEntries={totalEntries}
        skippedDup={skippedDup}
      />

      {/* Daily chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold text-foreground">
            日別トークン消費
          </CardTitle>
        </CardHeader>
        <CardContent>
          <DailyChart data={dayData} />
        </CardContent>
      </Card>

      {/* Project table */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-semibold text-foreground">
            プロジェクト別トークン消費
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ProjectTable byProject={byProject} />
        </CardContent>
      </Card>
    </main>
  )
}
